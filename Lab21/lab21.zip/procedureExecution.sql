EXECUTE creaMaterial 5000,'Martillos Acme',250,15;
select * from materiales where clave = 5000;