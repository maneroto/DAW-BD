DROP TABLE	Materiales
DROP TABLE	Proveedores
DROP TABLE	Proyectos
DROP TABLE	Entregan