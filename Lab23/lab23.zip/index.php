<?php include("sections/_header.php")?>
<a href="views/registroIncidente.php" class="btn">Registrar incidente</a>
<a href="views/visualizarIncidente.php" class="btn">Visualizar incidente</a>
<a href="views/youtubeAPI.php" class="btn">Youtube API</a>
<?php include("sections/_footer.php")?>