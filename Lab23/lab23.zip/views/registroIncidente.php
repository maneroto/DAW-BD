<?php include("../sections/_header.php")?>
<?php include("../sections/_formaRegistroIncidente.php")?>
<?php include("../sections/_footer.php")?>