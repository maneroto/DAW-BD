<?php include("../sections/_header.php")?>
<?php include("../sections/_tablaIncidentes.php")?>
<?php include("../sections/_footer.php")?>