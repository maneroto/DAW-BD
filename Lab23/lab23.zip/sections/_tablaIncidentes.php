    <h2>Incidentes</h2>
    <table id="tableDisplay">
        <tr>
            <td><button class="btn" id="byDate" name="byDate">Fecha del incidente</button></td>
            <td><button class="btn" id="byPlace" name="byPlace">Lugar del incidente</button></td>
            <td><button class="btn" id="byIncident" name="byIncident">Incidente</button></td>
        </tr>
    </table>
    <a href="registroIncidente.php" class="btn">Registrar incidente</a>
    <?php $js.='<script type="text/javascript" src = "'.$httpProtocol.$host.$url.'js/initTable.js"></script>';?>

      