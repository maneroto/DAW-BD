            </div>
      <!--JavaScript at end of body for optimized loading-->
      <?php echo $js?>
      <script>M.AutoInit()</script>
    </body>
  </html>