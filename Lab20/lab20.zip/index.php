<?php
    include("sections/_header.php");
?>
<section>
<?php
include("sections/_form.php");
// nombre, colorFavorito, animal y hobby
?>
</section>
<?php
    include("sections/_footer.php");
?>