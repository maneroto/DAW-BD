            <div class="row">
            <form method="post" action = "<?php echo 'https://'.$host.'/Lab20/php/welcome.php'?>" id="uForm">
                <div class="row">
                    <div class= "input-field col s12">
                        <label for="name">Name</label>
                        <input type="text" name="name"/>
                    </div>
                </div>
                <div class="row">
                    <div class= "input-field col s12">
                        <label for="color">Color</label>
                        <input type="text" name="color"/>
                    </div>
                </div>
                <div class="row">
                    <div class= "input-field col s6">
                        <label for="animal">Animal</label>
                        <input type="text" name="animal"/>
                    </div>
                    <div class= "input-field col s6">
                        <label for="hobby">Hobby</label>
                        <input type="text" name="hobby"/>
                    </div>
                </div>
                <div class="row">
                    <input type="submit" value="Submit" class="btn"/>
                </div>
            </form>
            </div>

            

            
            
            
            