            <footer class = "page-footer">
                <div class = "footer-copyright">
                    <div class = "container">
                        @ 2019 Copyright ABAK
                    </div>
                </div>
            </footer>
        </main>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/js/materialize.min.js"></script>
        <script type="text/javascript">
            document.addEventListener('DOMContentLoaded', function() {
            var elems = document.querySelectorAll('.sidenav');
            var instances = M.Sidenav.init(elems, options);
            });
        </script>
    </body>
</html>